local function getGrenadeDamage(skill, isFromItem, attacker, ...)
    if isFromItem and string.find(skill.Name, "_Grenade_") and attacker:HasTag("MechEngi_ExplosivesExpert") then
        local damageList, deathType = Game.Math.GetSkillDamage(skill, isFromItem, attacker, ...)
        damageList:Multiply(1+(attacker.WarriorLore*.1))
        return damageList, deathType
    end
end

Ext.RegisterListener("GetSkillDamage", getGrenadeDamage)