local function getGrenadeDamage(skill, attacker, isFromItem, ...)
    if isFromItem and string.find(skill.Name, "Grenade") then
        local damageList, deathType = Game.Math.GetSkillDamage(skill, attacker, isFromItem, ...)
        damageList:Multiply(1+(attacker.WarriorLore*0.1))
        return damageList, deathType
    end
end
Ext.RegisterListener("GetSkillDamage", getGrenadeDamage)

local function replaceSkill(character, oldSkill, newSkill)
    local oldSkillSlot = NRD_SkillBarFindSkill(character, oldSkill)
    CharacterRemoveSkill(character, oldSkill)
    CharacterAddSkill(character, newSkill, 0)
    local newSkillSlot = NRD_SkillBarFindSkill(character, newSkill)
    if newSkillSlot ~= nil then NRD_SkillBarClear(character, newSkillSlot) end
    if oldSkillSlot ~= nil then NRD_SkillBarSetSkill(character, oldSkillSlot, newSkill) end
    print(newSkillSlot)
    print(oldSkillSlot)
    print(oldSkill)
    print(newSkill)
end
Ext.NewCall(replaceSkill, "MechEngi_EXT_ReplaceSkill", "(CHARACTERGUID)_character, (STRING)_oldSkill, (STRING)_newSkill");