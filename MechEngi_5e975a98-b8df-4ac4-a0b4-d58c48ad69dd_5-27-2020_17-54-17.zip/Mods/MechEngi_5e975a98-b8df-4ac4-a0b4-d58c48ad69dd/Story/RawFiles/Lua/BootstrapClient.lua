-- Return new damage in tooltip
local function grenadeDescriptionParam (skill, character, isFromItem, param)
    if string.find(skill.Name, "_Grenade") and param == "Damage" then
        local damageRange = Game.Math.GetSkillDamageRange(character, skill)
        if damageRange ~= nil then
	damageRange:Multiply(1+(character.WarriorLore*0.1))
            local damageTexts = {}
            local totalDamageTypes = 0
            for damageType,damage in pairs(damageRange) do
                local min = damage[1]
                local max = damage[2]
                if min > 0 or max > 0 then
                    if max == min then
                        table.insert(damageTexts, Mods.LeaderLib.Game.GetDamageText(damageType, string.format("%i", max)))
                    else
                        table.insert(damageTexts, Mods.LeaderLib.Game.GetDamageText(damageType, string.format("%i-%i", min, max)))
                    end
                end
                totalDamageTypes = totalDamageTypes + 1
            end
            if totalDamageTypes > 0 then
                if totalDamageTypes > 1 then
                    return Mods.LeaderLib.Common.StringJoin(", ", damageTexts)
                else
                    return damageTexts[1]
                end
            end
        end
    end
end
Ext.RegisterListener("SkillGetDescriptionParam", grenadeDescriptionParam)